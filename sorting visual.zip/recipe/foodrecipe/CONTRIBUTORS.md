#
# Contributing to Food Recipe

First off, thanks for taking the time to contribute! ❤️
All types of contributions are encouraged and valued. Be it big code changes, small code changes and even documentation changes.
Please make sure you read and follow the Code Of Conduct while contributing to this project. Thanks 😊

# Message
Enter your Name, Github Link & Your E-Mail Address in the given format. Don't try to change anything else!!!
<code>| Name | Github Link | E-Mail Address |</code> 

# List of Contributors
<p>[*] Make sure you have updated your Name, Github link & E-Mail Id (enter your e-mail just after mailto:)!!!</p>
<br>
  
| Name | Github Link | Email ID |
| ------|----------|---------- |
| Dhruv Bhatia | <a href="https://github.com/dhruvbhatia1">Dhruv Bhatia</a> | <a href="mailto:example@gmail.com">E-Mail</a> |
| Pargat Singh | <a href="https://github.com/Pargat-Dhanjal">Pargat-Dhanjal</a> | <a href="mailto:pargat14@hotmail.com">E-Mail</a> |


<br>
<h1>
  Happy Hacking ❤💻
</h1>
